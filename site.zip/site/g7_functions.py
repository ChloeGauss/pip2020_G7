# -*- coding: utf-8 -*-
"""
Created on Wed Jan 13 16:36:25 2021

@author: Group 7
"""


import re
from datetime import datetime as dt
import locale
import numpy as np
import pandas as pd
import plotly.express as px
import dash_html_components as html
import dash_bootstrap_components as dbc


# Extraction of the date
def clean_date(extract_datetime: str) -> dt.strptime:
    """Documentation

    Parameters:
        extract_datetime: date of the article

    Attributes:
        channel: string date (varying)
        long_fr_month: list of months in french
        short_fr_month: list of months in french (abbreviation)
        case_1: format of string 'dd/mm/aaaa' or 'dd/mm/aa'
        case_2: format of string 'dd mois aaaa'
        case_3: format of string 'mois dd, aaaa'
        case_4: format of string 'mois aaaa'
        case_5: format of string 'dd.mm.aaaa' or 'dd.mm.aa'
        case_6: format of string 'mois.aaaa' or 'mois.aa'

    Out:
        date: in datetime
    """

    channel = str(extract_datetime)
    long_fr_month = [
        'janvier',
        'février',
        'mars',
        'avril',
        'mai',
        'juin',
        'juillet',
        'août',
        'septembre',
        'octobre',
        'novembre',
        'décembre'
        ]
    short_fr_month = [
        'janv',
        'fév',
        'mars',
        'avril',
        'mai',
        'juin',
        'juil',
        'aout',
        'sept',
        'oct',
        'nov',
        'déc'
        ]
    case_1 = re.compile(r'\d{2}/\d{2}/\d{2}')
    case_2 = re.compile(r'\d+ \w+ \d{4}')
    case_3 = re.compile(r'\w+ \d+, \d{4}')
    case_4 = re.compile(r'\w+  \d{4}')
    case_5 = re.compile(r'\d+.\d+.\d+')
    case_6 = re.compile(r'\w+.\d+')

    if case_1.match(channel) is not None:
        channel = case_1.findall(channel)[0]
        if len(channel.split('/')[2]) == 2:
            return dt.strptime(channel, '%d/%m/%y').strftime('%d/%m/%Y')
        else:
            return dt.strptime(channel, '%d/%m/%Y').strftime('%d/%m/%Y')

    elif case_2.match(channel) is not None:
        try:
            locale.setlocale(locale.LC_ALL, 'fr_FR.UTF-8')
            return(dt.strptime(channel, '%d %B %Y').strftime('%d/%m/%Y'))
        except Exception:
            locale.setlocale(locale.LC_ALL, 'en_GB.UTF-8')
            return(dt.strptime(channel, '%d %B %Y').strftime('%d/%m/%Y'))

    elif case_3.match(channel) is not None:
        channel = channel.split()
        if len(channel[1]) == 2:
            channel[1] = '0'+str(channel[1])
        if channel[0].lower() in long_fr_month:
            locale.setlocale(locale.LC_ALL, 'fr_FR.UTF-8')
            return(dt.strptime(' '.join(channel),
                               '%B %d, %Y').strftime('%d/%m/%Y'))
        elif len(channel[0]) == 4 or 'é' in channel[0]:
            channel[0] = channel[0]+'.'
            locale.setlocale(locale.LC_ALL, 'fr_FR.UTF-8')
            return(dt.strptime(' '.join(channel),
                               '%b %d, %Y').strftime('%d/%m/%Y'))
        elif len(channel[0]) >= 5:
            locale.setlocale(locale.LC_ALL, 'fr_FR.UTF-8')
            return(dt.strptime(' '.join(channel),
                               '%B %d, %Y').strftime('%d/%m/%Y'))
        else:
            locale.setlocale(locale.LC_ALL, 'en_GB.UTF-8')
            return(dt.strptime(' '.join(channel),
                               '%b %d, %Y').strftime('%d/%m/%Y'))

    elif case_4.match(channel) is not None:
        locale.setlocale(locale.LC_ALL, 'fr_FR.UTF-8')
        return(dt.strptime(channel, '%B %Y').strftime('%d/%m/%Y'))

    elif case_5.match(channel) is not None:
        channel = channel.strip()
        if len(channel.split('.')[2]) == 4:
            return(dt.strptime(channel, '%d.%m.%Y').strftime('%d/%m/%Y'))
        else:
            return(dt.strptime(channel, '%d.%m.%y').strftime('%d/%m/%Y'))

    elif case_6.match(channel) is not None:
        channel = channel.strip()
        if channel.split('.')[0].lower() in short_fr_month:
            locale.setlocale(locale.LC_ALL, 'fr_FR.UTF-8')
            return(dt.strptime(channel, '%b%Y').strftime('%d/%m/%Y'))
        else:
            locale.setlocale(locale.LC_ALL, 'en_GB.UTF-8')
            return(dt.strptime(channel, '%b.%Y').strftime('%d/%m/%Y'))

    else:
        if case_2.findall(channel) != []:
            return clean_date(case_2.findall(channel)[0])
        elif case_1.findall(channel) != []:
            return clean_date(case_1.findall(channel)[0])
        elif case_3.findall(channel) != []:
            return clean_date(case_3.findall(channel)[0])
        else:
            return None


def year_list(df: pd.DataFrame, column_date: str = 'art_date') -> list:
    """Documentation

    Parameters:
        df: DataFrame of articles
        colunm_date: Name of the column where is the tags (default: 'art_date')

    Out:
       list_year: list of finals topics
    """

    list_year = []
    for i in range(len(df[column_date])):
        if int(str.split(df[column_date][i], '/')[2]) not in list_year:
            list_year.append(int(str.split(df['art_date'][i], '/')[2]))
    list_year.sort()

    return list_year


# Topics Cleaning
def cleansing(extract_topic: list) -> list:
    """Documentation

    Return a list of topics after cleaning

    Parameters:
        extract_topic: list of topics extract

    Out:
        clean_topic: list of topics clean
    """

    # Creation of the output list
    clean_topic = []

    # For each field, we remove the 'parasitic' characters, we add the result
    # in the output list
    for i in range(0, len(extract_topic)):
        if ',' in extract_topic[i]:
            for j in extract_topic[i].split(','):
                clean_topic.append(j.strip(" ```'''\"[]#"))
        else:
            clean_topic.append(extract_topic[i].strip(" '\"[]#"))

    # Remove the duplicates
    clean_topic = list(np.unique(clean_topic))
    clean_topic.remove('')

    return clean_topic


# Treatment of topics
def theme_treatment(df: pd.DataFrame, column_tag: str = 'art_tag') -> list:
    """Documentation

    Return list of topic after treatment

    Parameters:
        df: DataFrame of articles
        colunm_tag: Name of the column where is the tags (default: 'art_tag')

    Attributes:
        topic: list of topics

    Out:
       final_topic: list of finals topics
    """
    topic = list(df[column_tag].dropna())

    extract_topic = [y.strip(" '\"[]#") for x in topic for y in x]
    final_topic = list(np.unique(extract_topic))

    return final_topic


# Function to create themes options for the dropdown
def get_topic_options(df: pd.DataFrame) -> list:
    """Documentation

    Parameters:
        df: path to the database

    Attributes:
        topic_list: 'themes' field
        dict_topic: dictionary with the languages found in the database

    Out:
        topic_option: list of dictionaries for dropdowns
    """

    topic_list = df['src_name'].dropna().unique()

    # Declaration of topic_option. It needs to be declared in order to use the
    # append method.
    topic_option = []

    # This 'for' is to put each language in the dictionary and add it to the
    # list 'topic_option'.
    for n in range(0, len(topic_list)):
        dict_topic = {'label': topic_list[n], 'value': topic_list[n]}
        topic_option.append(dict_topic)
    return topic_option


# Function to retrieve minimum and maximum dates
def interval_date(df: pd.DataFrame) -> tuple:
    """Documentation

    Parameters:
        df: we take dataframe type articles as inputs

    Attributes:
        date: we retrieve the column art_date where the dates are stored

    Out:
        min_date: the minimum date of the column is retrieved
        max_date: the maximum date of the column is retrieved
    """
    date = df[['art_date']]
    min_date = min(date['art_date'])
    max_date = max(date['art_date'])
    return (min_date, max_date)


# This functions allows use to make a pie chart
def plot_pie_chart(df: pd.DataFrame, plot_filter: str,
                   pie_title: str) -> px.pie:
    """Documentation

    Return a pie chart .

    Parameters:
        df : Dataframe of articles
        plot_filter : Variable used to compare articles
        pie_title: Title given to the plot

    Attributes:
        grp_variable : Dataframe filter by plot_filter

    Out:
        fig : Plot pie
    """

    df[plot_filter].fillna('Unknown', inplace=True)
    grp_variable = df.groupby(plot_filter)[['art_title']].count()
    grp_variable = grp_variable.reset_index()
    grp_variable = grp_variable.rename(columns={'art_title': 'nb_articles'})
    fig = px.pie(grp_variable, values='nb_articles', names=plot_filter,
                 title=pie_title)
    return fig


# Show Article
def show_article(art_index: list, df: pd.DataFrame):
    """Documentation

    Return the articles cards.

    Parameters:
        art_index : list of article index in int

    Output:
        card : list of html.Div for display with the articles cards
    """

    card = []
    for nb in art_index:
        # In the index of selected articles
        card.append(html.Div([
            dbc.Col(html.Div([
                dbc.Card(
                    dbc.CardBody([
                        dbc.CardLink(
                            html.H5(
                                df['art_title'][nb],
                                className='card_title',
                                ),
                            href='/page-'+str(nb),
                            target='blank'
                            ),
                        html.P(
                            html.P(
                                ' '.join(
                                    df['art_content'][nb].split(' ')[:50]
                                    ),
                                style={
                                    'width': 'auto',
                                    'align': 'justify',
                                    'text-align': 'justify'
                                    }
                                )
                            ),
                        ]), className='w-100 mb-3')
            ]))
        ]))
    return card
